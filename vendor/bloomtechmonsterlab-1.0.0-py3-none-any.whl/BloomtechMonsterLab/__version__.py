"""
Version information for BloomtechMonsterLab.
"""

__version__ = "1.0.0"
__version_info__ = (1, 0, 0)
