"""
Generic Random Generator class to replace Fortuna dependency.

This module provides similar functionality to Fortuna's random generation methods
using Python's built-in random module.
"""

import random
from typing import Any, List, Union, Callable


class RandomGenerator:
    """
    A generic random generator class that provides functionality similar to Fortuna.
    
    This class replaces Fortuna's TruffleShuffle, triangular, canonical, 
    percent_true, plus_or_minus, and random_value functions.
    """
    
    def __init__(self, seed: int = None):
        """
        Initialize the random generator.
        
        Args:
            seed: Optional seed for reproducible random generation
        """
        if seed is not None:
            random.seed(seed)
    
    def truffle_shuffle(self, items: Union[List[Any], tuple]) -> Callable:
        """
        Create a function that randomly selects from a list of items.
        Similar to Fortuna's TruffleShuffle.
        
        Args:
            items: List or tuple of items to choose from
            
        Returns:
            A callable function that returns a random item from the list
        """
        def shuffle_func(*args, **kwargs):
            return random.choice(items)
        return shuffle_func
    
    def triangular(self, low: float, high: float, mode: float) -> float:
        """
        Generate a random number using triangular distribution.
        Similar to Fortuna's triangular function.
        
        Args:
            low: Lower bound
            high: Upper bound  
            mode: Mode (most likely value)
            
        Returns:
            A random float from triangular distribution
        """
        return random.triangular(low, high, mode)
    
    def canonical(self) -> float:
        """
        Generate a random float between 0.0 and 1.0.
        Similar to Fortuna's canonical function.
        
        Returns:
            A random float between 0.0 and 1.0
        """
        return random.random()
    
    def percent_true(self, probability: float) -> bool:
        """
        Return True with given probability percentage.
        Similar to Fortuna's percent_true function.
        
        Args:
            probability: Probability percentage (0-100)
            
        Returns:
            True with given probability, False otherwise
        """
        return random.random() < (probability / 100.0)
    
    def plus_or_minus(self, value: Union[int, float]) -> Union[int, float]:
        """
        Return the value with random sign (+ or -).
        Similar to Fortuna's plus_or_minus function.
        
        Args:
            value: The value to apply random sign to
            
        Returns:
            The value with random positive or negative sign
        """
        return value if random.choice([True, False]) else -value
    
    def random_value(self, items: Union[List[Any], tuple]) -> Any:
        """
        Return a random value from a list or tuple.
        Similar to Fortuna's random_value function.
        
        Args:
            items: List or tuple of items to choose from
            
        Returns:
            A random item from the collection
        """
        return random.choice(items)


# Create a global instance for convenience
random_gen = RandomGenerator()
